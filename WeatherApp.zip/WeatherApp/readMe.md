1. open the code in sublime editor.
2. open index.html
3. right click on index.html and open in browser.