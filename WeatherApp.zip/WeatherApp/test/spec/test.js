(function () {
  'use strict';

  describe('Testing with Jasmine', function () {
    describe('populateDate', function () {
      it('appends the timestamp to timestamp div', function () {
      var dummyElement = document.createElement('div');
      document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
        expect(document.getElementById('datetime').innerHTML).toEqual("Wednesday, November 30, 2016");
      });
    });
  });
  describe('Testing with Jasmine', function () {
    describe('startTime', function () {
      it('appends the time to txt div', function () {
      var dummyElement = document.createElement('div');
      document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);
        expect(document.getElementById('txt').innerHTML).toEqual("22:48:56");
      });
    });
  });
  describe('Testing with Jasmine', function () {
    describe('checkTime', function () {
      it('add zero in front of numbers < 10', function () {
        expect(9).returnValue("09");
      });
    });
  });

})();
